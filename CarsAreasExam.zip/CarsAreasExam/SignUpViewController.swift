//
//  SignUpViewController.swift
//  CarsAreasExam
//
//  Created by user on 11/12/2020.
//

import UIKit

class SignUpViewController: UIViewController {
    
    @IBOutlet weak var loginTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passTF: UITextField!
    @IBOutlet weak var confirmPassTF: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
       
    var login: String = ""
    var email: String = ""
    var pass: String = ""
    var confirmPass: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
    }
    
    @IBAction func returnToSignInVC(_ sender: Any) {
        if (loginTF.text != nil) && (emailTF.text != nil) && (confirmPassTF.text != nil) && (passTF.text != nil) {
            if confirmPassTF.text == passTF.text {
                login = loginTF.text!
                email = emailTF.text!
                pass = passTF.text!
                confirmPass = confirmPassTF.text!
                performSegue(withIdentifier: "returnSI", sender: nil)
                
            }
        } else {
            print("bad")
        }
    }
    
}
