//
//  StartScreenViewController.swift
//  CarsAreasExam
//
//  Created by user on 11/12/2020.
//

import UIKit

class StartScreenViewController: UIViewController {
    
    @IBOutlet weak var leftUpMenuButton: UIButton!
    @IBOutlet weak var nameLabelUser: UILabel!
    @IBOutlet weak var locationLabelUser: UILabel!
    @IBOutlet weak var rightUpMenuButton: UIButton!
    @IBOutlet weak var leftUpMenuImage: UIImageView!
    @IBOutlet weak var upMenu: UIView!
    @IBOutlet weak var leftMenu: UIView!
    
    
    override func viewWillAppear(_ animated: Bool) {
        leftUpMenuButton.isHidden = false
        leftUpMenuImage.isHidden = false
        upMenu.isHidden = true
        leftMenu.isHidden = true

    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func OpenCloseUpMenuButtonAction(_ sender: Any) {
        upMenu.isHidden = false
        leftMenu.isHidden = false
        leftUpMenuButton.isHidden = true
        leftUpMenuImage.isHidden = true
    }
    
    @IBAction func closeUpMenuButtonAction(_ sender: Any) {
        leftMenu.isHidden = true
        upMenu.isHidden = true
        leftUpMenuButton.isHidden = false
        leftUpMenuImage.isHidden = false
        
    }
}
