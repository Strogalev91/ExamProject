//
//  ViewController.swift
//  CarsAreasExam
//
//  Created by user on 11/12/2020.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var loginWithFacebookButton: UIButton!
    
    private var login: String = ""
    private var password: String = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }

    func getUserDetail() {
        login = loginTextField.text!
        password = passwordTextField.text!
    }
/*    func getUserDetails(name: String) {
        let url = "http://cars.areas.su/"
        AF.request(url as! URLConvertible, method: .get).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                
                print("JSON: \(json)")
            case .failure(let error):
                print(error)
            }
        }
    }
*/
    
    func chechAuthorization(name: String) {
        if loginTextField.text == nil {
            print("textfileld is empty")
            return
        } else if (loginTextField.text == login) && (passwordTextField.text == password) {
            print("CoolCheckAuthorization")
        }
        loginTextField.resignFirstResponder()
        
    }
    
    @IBAction func singInActionButton(_ sender: Any) {
        if (loginTextField.text == nil) || (passwordTextField.text == nil) {
            print("is empty")
        } else  if (loginTextField.text == login) && (passwordTextField.text == password) {
            performSegue(withIdentifier: "goToStartVC", sender: nil)
            print("OK")
        }
        
    }
}

